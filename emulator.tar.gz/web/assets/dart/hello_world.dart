import 'dart:html';

import 'package:smartwatch/emulator.dart';

class HelloWorldApp implements EmulatorApplication {
  Emulator _emulator;

  @override
  void init(Emulator emulator) {
    _emulator = emulator;
  }

  @override
  void update(num delta) {}

  @override
  void render() {
    _emulator.screen.drawText('Hello World!', 40, 40);
  }

  @override
  void destroy() {}
}

void main() {
  var emulator =
      new Emulator(querySelector('#emulator'), 320, 320, new HelloWorldApp());
  emulator.start();
}
