COSC345
========================
A smart watch application prototype using HTML, CSS &amp; Dart

Set Up
------
Upon cloning the repository you should run the following to fetch the dependencies

    $ pub get

Building
--------
Building this project requires the Dart SDK installed.
Simply run the following from the base directory.

    $ pub build

The resulting files will be in the build/web directory.

### Note
Loading of images and sounds will only work when the emulator is being served (ie pub serve).

### Serving Directly
Alternatively you can just run the following, to make it accessible at http://localhost:8080

    $ pub serve

### Testing
The project's tests can be run by running the following from the base directory.
As this project is designed to run in a browser, you need to pass the name of the browser 
to run the tests on as an argument.

    $ pub run test -p <dartium|content-shell|chrome|firefox>